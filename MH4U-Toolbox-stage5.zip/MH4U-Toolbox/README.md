# MH4U Toolbox

Editor save dan database Monster Hunter 4 Ultimate. Situs statis: tidak butuh build, cukup di-host di GitHub Pages.

## Menjalankan

Database dimuat lewat `fetch()`, jadi buka lewat server web, bukan langsung dari `file://`.

- Lokal: `python3 -m http.server 8000` di folder project, lalu buka `http://localhost:8000`
- GitHub Pages: lihat bagian "Publikasi ke GitHub Pages" di bawah.

## Struktur

```
index.html
css/            base, layout, components
js/core/        app, save-codec, i18n
js/editor/      preset dan pouch editor
js/database/
  loader.js     HANYA mengambil data (manifest, tabel, terjemahan, ikon)
  search/       mesin pencarian + 6 modul: monsters, items, weapons, armor, quests, materials
js/data/        mapping ikon item/equipment
js/utils/
database/
  manifest.json daftar 24 tabel (baris, kolom, ukuran, grup)
  tables/*.json satu file per tabel
  dbtr.json     terjemahan label
  icons-manifest.json   kunci ikon -> assets/icons/*.webp
assets/icons/   ikon .webp
docs/           AUDIT-DATABASE.md, SEARCH-API.md
tools/          build-database.py + tools/source/dbz.gz (sumber asli)
tests/          pengujian Node (tanpa dependensi)
```

## Stage 5: database modular

- **Loader terpisah dari pencarian.** `loader.js` hanya mengambil dan meng-cache tabel. Pencarian ada di `js/database/search/`.
- **Tidak memuat semuanya sekaligus.** Membuka menu Database hanya memuat 8 tabel inti (sekitar 1,1 MB dari total 2,5 MB JSON). Tabel relasi besar (`components`, `gathering`, `quest_rewards`, `hunting_rewards`, `item_to_skill_tree`) baru diambil saat halaman yang butuh membukanya. GitHub Pages biasanya mengompres file JSON saat mengirimnya, sehingga ukuran transfer lebih kecil dari angka di atas.
- **Path relatif.** Loader menghitung lokasi `database/` dari lokasi `loader.js` sendiri, jadi tetap benar di `https://user.github.io/nama-repo/`. Tidak ada path yang diawali `/`.
- **Audit 24 tabel:** `docs/AUDIT-DATABASE.md` (dibuat otomatis).
- **Modul pencarian:** `docs/SEARCH-API.md`. Contoh di konsol browser:

```js
await MH4USearch.search('weapons', 'rath', { filters: { wtype: 'Great Sword', element: 'Fire' }, sort: 'attack' });
await MH4USearch.search('materials', '', { filters: { monster: 'Rathalos', rank: 'HR' } });
await MH4USearch.searchAll('potion');
MH4UDatabaseLoader.stats();   // tabel apa saja yang sudah dimuat
```

Perbaikan dari Stage 4: `iu()` di `app.js` masih mengira manifest ikon berisi base64 (`atob`), padahal sejak Stage 4 isinya path file `.webp`. Sekarang ikon dimuat langsung dari `assets/icons/`.

Belum dilakukan: kotak pencarian di UI Database masih memakai pencarian substring lama. Menyambungkannya ke `MH4USearch` adalah langkah berikutnya.

## Memperbarui database

Sumber asli ada di `tools/source/dbz.gz`. Setelah mengubahnya (atau mengubah `INFO` di skrip):

```
python3 tools/build-database.py
```

Skrip menulis ulang `database/tables/*.json`, `database/manifest.json`, dan `docs/AUDIT-DATABASE.md`.

## Pengujian

```
node tests/search.test.js       # loader + 6 modul pencarian dengan data asli
node tests/app-views.test.js    # menjalankan app.js dan merender semua daftar/detail
```

`app-views.test.js` membuang tabel non-inti sebelum tiap tampilan dirender, jadi daftar tabel yang dibutuhkan tiap halaman (`NEED_LIST` / `NEED_DET` di `app.js`) terbukti cukup. Tes ini memakai DOM palsu, bukan browser sungguhan; uji manual di browser tetap perlu.

## Publikasi ke GitHub Pages

1. Buat repo di GitHub, lalu unggah seluruh isi folder ini (`index.html` harus berada di root repo). File `.nojekyll` sudah disertakan.
2. Repo > Settings > Pages > Build and deployment > Source: **Deploy from a branch**, Branch: `main`, folder `/ (root)`.
3. Tunggu satu sampai dua menit. Link: `https://USERNAME.github.io/NAMA-REPO/`
4. Nama file di GitHub Pages peka huruf besar/kecil. Jangan mengganti nama file di `assets/icons/` tanpa memperbarui `database/icons-manifest.json`.

Sebelum memakai save utama, uji dulu dengan salinan save: load, edit, export, lalu bandingkan hasilnya.

## Kredit

- **mh4edit** oleh Rokumaehn (MIT): format save, ikon equipment, daftar nama.
- **MH4U Database** oleh Gathering Hall Studios / DavianCorp (MIT): data skill, batas stack item, isi menu Database.
- Gambar dan ikon asli milik Capcom.
